    
    <?php get_header(); ?>
    <div class="body-content">
                <div id="action-banner" class="bannerdiv">
            <i class="fa fa-phone" aria-hidden="true"></i> Miễn phí tư vấn <b>0901 395 886</b>
        </div>        
        <div id="mini-action" class="callToAction">
            <div onclick="ShowAction()" class = "eModal-1 minidiv"><i class="fa fa-comments" aria-hidden="true"></i> Miễn phí tư vấn</div>
        </div>
        <?php echo do_shortcode('[contact-form-7 id="309" title="Form-tu-van"]'); ?>
        <div class="col-md-12" id="banner-ve-chung-toi">
            <div id="banner" >
                <div class="head-bg-chung-toi">
                    
                </div>
                <div id="ani-1" class="content-banner-about-us">
                    <div id="toptext-about-us">
                        <h1 id="toptext">
                            <span>Về chúng tôi</span>
                        </h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12" id="content-abour-us">
            <div class="row">
                <div class="col-md-10 col-lg-offset-1">
                    <br /><strong>Công ty Seo Magic là ai?</strong>
                    <br />Seo Macgic là một đơn vị hàng đầu trong lĩnh vực cung cấp các giải pháp maketing online, thiết kế website, dịch vụ quảng cáo hoàn hảo nhất cho các tổ chức, doanh nghiệp và cá nhân trên toàn quốc.Với sự nhanh nhạy trong thời cuộc, nhạy bén trong tư duy cùng với đội ngũ nhân sự tài năng, cần cù và chuyên nghiệp chúng tôi tự tin sẽ mang đến cho qúy khách hàng các giải pháp tối ưu nhất để tối đa hóa lợi nhuận của mình.
                    <br /> Chúng tôi biết rằng khi đã sử dụng vụ thì điều kiện đầu tiên mà quý khách hàng quan tâm nhất là đảm bảo được kết quả và đúng hẹn. Với những gì đã làm được, chúng tôi tự tin và khẳng định chắc chắn rằng sẽ hoàn thành xuất sắc nhất nhiệm vụ mà khách hàng giao phó.
                    <br />Chúng tôi không chỉ hướng đến mục tiêu trở thành một marketing agency trong khu vực mà còn muốn trở thành một công ty truyền thông hàng đầu tại Việt Nam. Để đạt được kết quả trên chúng tôi luôn xác định: sự hài lòng và thành công của khách hàng chính là mục tiêu phát triển của công ty, chình vì vậy Magic luôn đặt việc tuyển chọn, đào tạo nguồn nhân lực lên hàng đầu.
                    <br /><strong>Tại sao nên chọn Công ty seo Magic.</strong>
                    <br />Chúng tôi biết rằng các trang thông tin của bạn ( Web, Fanpage) chính là nơi để thể hiện bản săc doanh nghiệp cũng như khẳng định được dịch vụ của bạn. Và chúng tôi mang đến cho bạn những những giải pháp hoàn hảo, phù hợp và độc nhất trên mọi lĩnh vực kinh doanh của bạn.
                    <br />- Dịch vụ seo tại Magic sẽ giúp website của bạn được tối ưu hóa thân thiện hơn với cỗ các cỗ máy tìm kiếm với thứ hạng cao nhất và mang lại cho bạn một nguồn khách hàng ổn định giúp bạn có thể tối ưu hóa được lợi nhuận cũng như mở rộng thị trường và đa dạng hóa sản phẩm một cách dễ dàng nhất.
                    <br />- Bạn sẽ nhận được sự tư vấn nhiệt tình và chuyên nghiệp nhất với các bản kế hoạch đầy đủ chi tiết để phù hợp với từng giai đoạn trong chiến dịch kinh doanh của bạn.
                    <br />- Chúng tôi giúp bạn xây dựng một hệ thống nội dung chất lượng nhất để thu hút, níu chân người mua hàng.
                    <br />- Với các phương pháp làm việc khoa học nhất website của bạn sẽ được quảng cáo rộng rãi trên khắp các phương tiện truyền thông để tạo tiền để đảm bảo chắc chắn thứ hạng từ khóa xuất hiện với thứ hạng cao nhất và ổn định lâu dài nhất
                    <br />Với chúng tôi internet là niềm đam mê và hạnh phúc là khi được góp một phần vào sự thành công của quý khách bạn hoàn toàn có thể kiểm chứng hiệu quả công việc của chúng tôi bằng cách xem những gì chúng tôi đã đạt được đối với những khách hàng trong quá khứ tại đây hoặc có thể yêu cầu chúng tôi cung cấp bất kì thông tin nào của khách hàng để tự mình chứng thực.
                    <br />Bạn đã sẵn sàng làm việc với một công ty SEO hàng đầu chưa? Hãy gọi cho chúng tôi theo hotline 0901 395 886 ngay hôm nay hoặc gửi yêu cầu cho chúng tôi theo form dưới đây để chúng tôi hỗ trợ bạn được nhanh nhất. Sẽ là tuyệt với nhất nếu như bạn có thể bớt chút thời gian mô tả về những dự định của bạn. Càng biết được nhiều thông tin chúng tôi càng dễ dàng hơn trong việc đưa ra các giải pháp tối ưu nhất cho bạn.
                    <!-- <div style="display:none;">
                        <br />NHẬN BÁO GIÁ SEO MIẾN PHÍ
                        <br />Họ trên bạn ( bắt buộc)
                        <br />Công ty ( bắt buộc)
                        <br /> Địa chỉ email ( bắt buộc)
                        <br />Điện thoại: ( Bắt buộc)
                        <br />Hãy cho chúng tôi biết ngân sách hàng tháng của bạn cho dự án này là bao nhiêu ( tùy chọn)
                        <br />Hãy cho chúng tôi biết rõ yêu cầu và ý tưởng của bạn.
                    </div> -->
                </div>
            </div>
        </div>
        <?php get_footer(); ?>
    </div>
</body>
</html>
